#include "Item.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Item yapısını oluşturur ve döner
Item* createItem(const char* name) {
    // Bellek tahsisi yap
    Item* newItem = (Item*)malloc(sizeof(Item));
    if (newItem == NULL) {
        return NULL; // Bellek tahsisi başarısızsa NULL dön
    }

    // Item adını kopyalamak için bellek tahsis et
    newItem->name = strdup(name);
    if (newItem->name == NULL) {
        free(newItem); // Eğer isim için bellek ayrılmazsa, item'in belleğini serbest bırak
        return NULL;
    }

    return newItem; // Oluşturulan item'i döner
}

// Destroy the item, free the allocated memory
void destroyItem(Item* item) {
    if (item == NULL) return; // Eğer item NULL ise hiçbir şey yapma

    if (item->name != NULL) {
        free(item->name); // item->name için ayrılmış belleği serbest bırak
    }

    free(item); // item'in kendisi için ayrılmış belleği serbest bırak
}


void displayItems(const Item* items) {
    const Item* current = items;
    while (current) {
        printf("- %s\n", current->name);
        current = current->item;
    }
}